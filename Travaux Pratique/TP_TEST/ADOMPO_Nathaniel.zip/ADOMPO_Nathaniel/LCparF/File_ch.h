#ifndef FILE_TAB_H

#define FILE_TAB_H
#include "Element.h"
#include "File_.h"

typedef struct sFile File;

#endif