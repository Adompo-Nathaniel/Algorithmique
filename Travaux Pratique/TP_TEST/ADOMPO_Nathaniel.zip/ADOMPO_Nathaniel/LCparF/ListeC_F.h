#ifndef LISTEC_CH2_H
#define LISTEC_CH2_H

#include "Liste_.h"
#include "cellule2.h"
typedef struct sListe ListeC;

void libererListeC(ListeC *list);

#endif
